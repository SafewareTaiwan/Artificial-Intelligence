import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import torch
import torch.nn as nn
import torch.optim as optim

class ProjectorOperator:
    """
    Implementation of the Projector Operator for dimensionality reduction
    in AI systems, focusing on task-relevant subspaces.
    """
    
    def __init__(self, method='pca', n_components=0.95):
        """
        Initialize the Projector Operator
        
        Parameters:
        method (str): Dimensionality reduction method ('pca', 'tsne', 'autoencoder')
        n_components: Number of components to keep (if int) or variance to retain (if float)
        """
        self.method = method
        self.n_components = n_components
        self.model = None
        self.projection_matrix = None
        
    def fit(self, X, y=None):
        """
        Learn the projection subspace from high-dimensional data
        
        Parameters:
        X (array-like): High-dimensional data
        y (array-like): Optional target variable for supervised projection
        """
        if self.method == 'pca':
            self.model = PCA(n_components=self.n_components)
            self.model.fit(X)
            self.projection_matrix = self.model.components_
            
        elif self.method == 'tsne':
            self.model = TSNE(n_components=2 if isinstance(self.n_components, int) else 2,
                              random_state=42)
            # t-SNE doesn't have a transform method in the same way, so we fit_transform
            # and store for reference
            self.projection = self.model.fit_transform(X)
            
        elif self.method == 'autoencoder':
            self._train_autoencoder(X)
            
        return self
    
    def transform(self, X):
        """
        Project high-dimensional data to the task-relevant subspace
        
        Parameters:
        X (array-like): High-dimensional data to project
        
        Returns:
        array-like: Projected data in the lower-dimensional subspace
        """
        if self.method == 'pca':
            return self.model.transform(X)
            
        elif self.method == 'tsne':
            # Note: t-SNE doesn't have a proper transform method
            # In practice, we'd need to use a different approach for new data
            raise NotImplementedError("t-SNE doesn't support transform for new data. Use fit_transform instead.")
            
        elif self.method == 'autoencoder':
            return self.encoder.predict(X)
            
    def fit_transform(self, X, y=None):
        """
        Learn the projection and apply it to the data
        
        Parameters:
        X (array-like): High-dimensional data
        y (array-like): Optional target variable
        
        Returns:
        array-like: Projected data
        """
        self.fit(X, y)
        return self.transform(X) if self.method != 'tsne' else self.projection
    
    def _train_autoencoder(self, X):
        """
        Train an autoencoder for nonlinear dimensionality reduction
        """
        # Convert to Tensor
        if not isinstance(X, torch.Tensor):
            X = torch.FloatTensor(X)
        
        # Define autoencoder architecture
        input_dim = X.shape[1]
        encoding_dim = self.n_components if isinstance(self.n_components, int) else int(input_dim * 0.1)
        
        class Autoencoder(nn.Module):
            def __init__(self, input_dim, encoding_dim):
                super(Autoencoder, self).__init__()
                self.encoder = nn.Sequential(
                    nn.Linear(input_dim, encoding_dim * 4),
                    nn.ReLU(),
                    nn.Linear(encoding_dim * 4, encoding_dim * 2),
                    nn.ReLU(),
                    nn.Linear(encoding_dim * 2, encoding_dim)
                )
                self.decoder = nn.Sequential(
                    nn.Linear(encoding_dim, encoding_dim * 2),
                    nn.ReLU(),
                    nn.Linear(encoding_dim * 2, encoding_dim * 4),
                    nn.ReLU(),
                    nn.Linear(encoding_dim * 4, input_dim),
                    nn.Sigmoid()
                )
            
            def forward(self, x):
                encoded = self.encoder(x)
                decoded = self.decoder(encoded)
                return decoded
        
        # Initialize model
        autoencoder = Autoencoder(input_dim, encoding_dim)
        criterion = nn.MSELoss()
        optimizer = optim.Adam(autoencoder.parameters(), lr=0.001)
        
        # Train the autoencoder
        num_epochs = 100
        for epoch in range(num_epochs):
            # Forward pass
            outputs = autoencoder(X)
            loss = criterion(outputs, X)
            
            # Backward pass and optimize
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            if (epoch+1) % 10 == 0:
                print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}')
        
        # Store the encoder part
        self.encoder = autoencoder.encoder
        self.autoencoder = autoencoder


def demonstrate_projector_operator():
    """
    Demonstration of the Projector Operator for AI optimization
    """
    print("=== Projector Operator Demonstration ===\n")
    
    # Generate synthetic high-dimensional data
    print("1. Generating synthetic high-dimensional data...")
    n_samples = 1000
    n_features = 100  # High-dimensional feature space
    n_informative = 10  # Only 10 features are actually relevant
    
    # Create data where only a subset of features are informative
    X = np.random.randn(n_samples, n_features)
    y = (X[:, :n_informative].sum(axis=1) > 0).astype(int)  # Target based on informative features
    
    print(f"   Data shape: {X.shape}")
    print(f"   Original dimensionality: {n_features}")
    print(f"   Informative features: {n_informative}")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Baseline model performance with all features
    print("\n2. Training baseline model with all features...")
    baseline_model = RandomForestClassifier(n_estimators=100, random_state=42)
    baseline_model.fit(X_train, y_train)
    baseline_pred = baseline_model.predict(X_test)
    baseline_accuracy = accuracy_score(y_test, baseline_pred)
    print(f"   Baseline accuracy: {baseline_accuracy:.4f}")
    
    # Apply Projector Operator to reduce dimensionality
    print("\n3. Applying Projector Operator to reduce dimensionality...")
    projector = ProjectorOperator(method='pca', n_components=0.95)  # Keep 95% variance
    X_train_projected = projector.fit_transform(X_train)
    X_test_projected = projector.transform(X_test)
    
    print(f"   Reduced dimensionality: {X_train_projected.shape[1]}")
    print(f"   Dimensionality reduction: {n_features} → {X_train_projected.shape[1]}")
    print(f"   Variance retained: {np.sum(projector.model.explained_variance_ratio_):.4f}")
    
    # Train model on projected data
    print("\n4. Training model on projected data...")
    projected_model = RandomForestClassifier(n_estimators=100, random_state=42)
    projected_model.fit(X_train_projected, y_train)
    projected_pred = projected_model.predict(X_test_projected)
    projected_accuracy = accuracy_score(y_test, projected_pred)
    print(f"   Projected data accuracy: {projected_accuracy:.4f}")
    
    # Compare performance
    print("\n5. Performance comparison:")
    print(f"   Baseline accuracy: {baseline_accuracy:.4f}")
    print(f"   Projected accuracy: {projected_accuracy:.4f}")
    print(f"   Accuracy difference: {abs(baseline_accuracy - projected_accuracy):.4f}")
    
    # Computational efficiency comparison
    import time
    
    # Time baseline prediction
    start_time = time.time()
    for _ in range(100):
        baseline_model.predict(X_test[:10])
    baseline_time = time.time() - start_time
    
    # Time projected prediction
    start_time = time.time()
    for _ in range(100):
        projected_model.predict(X_test_projected[:10])
    projected_time = time.time() - start_time
    
    print(f"\n6. Computational efficiency:")
    print(f"   Baseline prediction time (100 runs): {baseline_time:.4f} seconds")
    print(f"   Projected prediction time (100 runs): {projected_time:.4f} seconds")
    print(f"   Speed improvement: {baseline_time/projected_time:.2f}x")
    
    # Visualize the projection (if 2D)
    if X_train_projected.shape[1] == 2:
        plt.figure(figsize=(10, 6))
        plt.scatter(X_train_projected[:, 0], X_train_projected[:, 1], c=y_train, cmap='viridis', alpha=0.7)
        plt.colorbar()
        plt.title('Projection of High-Dimensional Data to 2D Subspace')
        plt.xlabel('Principal Component 1')
        plt.ylabel('Principal Component 2')
        plt.savefig('projection_visualization.png')
        print("\n7. Visualization saved as 'projection_visualization.png'")
    
    print("\n=== Demonstration Complete ===")


if __name__ == "__main__":
    demonstrate_projector_operator()