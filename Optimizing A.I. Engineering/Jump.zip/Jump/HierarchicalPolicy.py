# Pseudo-code for Hierarchical RL Jump
class HierarchicalPolicy:
    def __init__(self, high_level_policy, low_level_policies):
        self.high_level_policy = high_level_policy  # e.g., a neural network
        self.low_level_policies = low_level_policies # dict of policies

    def get_action(self, state, high_level_state):
        # If it's time for a new high-level decision, perform a JUMP.
        if self.time_for_new_goal():
            # X is the current high-level state
            # J is the high_level_policy network
            sub_policy_name = self.high_level_policy(high_level_state) # e.g., "merge_lane"
            self.active_sub_policy = self.low_level_policies[sub_policy_name] # The Jump

        # Delegate action selection to the chosen low-level policy
        action = self.active_sub_policy(state)
        return action