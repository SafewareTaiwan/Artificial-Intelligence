class DrivingModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.driving_network = ...  # E2E driving model
        self.dms_network = ...  # DMS feature extractor
        self.jump_network = nn.Linear(dms_feature_dim, 1)
    
    def forward(self, sensor_input, dms_input):
        driving_output = self.driving_network(sensor_input)
        dms_features = self.dms_network(dms_input)
        jump_prob = torch.sigmoid(self.jump_network(dms_features))
        # Use STE for training: discrete decision but continuous gradient
        if self.training:
            jump_decision = (jump_prob > 0.5).float()
            # For gradient, use jump_prob directly in backward
            jump_decision = jump_decision - jump_prob.detach() + jump_prob
        else:
            jump_decision = (jump_prob > 0.5).float()
        # Override driving output if jump_decision is 1
        final_output = driving_output * (1 - jump_decision)
        return final_output, jump_prob

# Loss function for supervised learning:
# loss = BCEWithLogitsLoss(jump_logits, labels) + driving_loss