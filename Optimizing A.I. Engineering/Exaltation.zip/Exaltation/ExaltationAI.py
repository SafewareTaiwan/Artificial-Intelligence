import torch
import torch.nn as nn
from exaltation_core import NeuralExaltation, DynamicExaltation
from exaltation_analyzer import ExaltationAnalyzer

# 1. Define the seed
# Assume input_x is a batch of sensor data (e.g., images, lidar point clouds)

# 2. Build the Exaltation Rule Sets (Modular Components)
# --- Shared Feature Extractor (Exalted from Sensor Data) ---
feature_layers = nn.Sequential(
    nn.Conv2d(3, 64, 5),
    nn.ReLU(),
    nn.Conv2d(64, 128, 5),
    nn.ReLU(),
    # ... more layers
)
feature_extractor = NeuralExaltation(feature_layers, name="FeatureExtractionExaltation")

# --- Trajectory Predictor (Exalted from Features) ---
trajectory_layers = nn.Sequential(
    nn.Linear(128 * 5 * 5, 512),
    nn.ReLU(),
    nn.Linear(512, 256),
    nn.ReLU(),
    nn.Linear(256, 50), # Output 25 (x,y) points for a trajectory
)
trajectory_predictor = NeuralExaltation(trajectory_layers, name="TrajectoryExaltation")

# --- Safety Occupancy Grid Predictor (Exalted from the SAME Features) ---
occupancy_layers = nn.Sequential(
    nn.Linear(128 * 5 * 5, 512),
    nn.ReLU(),
    nn.Linear(512, 256),
    nn.ReLU(),
    nn.Linear(256, 32*32), # Output a 32x32 occupancy grid
    nn.Sigmoid()
)
safety_occupancy_predictor = NeuralExaltation(occupancy_layers, name="SafetyOccupancyExaltation")

# 3. Compose the Full Model
class ModularAutonomousDriver(nn.Module):
    def __init__(self):
        super().__init__()
        self.feature_extractor = feature_extractor
        self.trajectory_predictor = trajectory_predictor
        self.safety_occupancy_predictor = safety_occupancy_predictor

    def forward(self, sensor_input):
        # First exaltation: sensor data -> features
        shared_features = self.feature_extractor(sensor_input)
        # Flatten for the fully-connected predictors
        flat_features = torch.flatten(shared_features, start_dim=1)

        # Parallel exaltations: features -> different outputs
        trajectory = self.trajectory_predictor(flat_features)
        occupancy_grid = self.safety_occupancy_predictor(flat_features)

        return trajectory, occupancy_grid

# 4. Use the Analyzer to Debug and Interpret
model = ModularAutonomousDriver()
analyzer = ExaltationAnalyzer(model.feature_extractor)

# Get a test batch
test_input = torch.randn(1, 3, 224, 224) # dummy image
traj, occ = model(test_input)

# Analyze the feature extraction process
analyzer.visualize_feature_evolution(test_input, channel_index=0)