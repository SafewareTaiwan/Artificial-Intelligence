# Core Module: exaltation_core.py

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional
import torch
import torch.nn as nn

class ExaltationOperator(nn.Module, ABC):
    """
    The abstract base class that defines an Exaltation operation.
    All user-defined exaltation modules should inherit from this.
    """

    def __init__(self, name: str = None):
        super().__init__()
        self.name = name
        # Hook manager to capture intermediate states
        self._hooks = {}
        self._intermediate_states = {}

    @abstractmethod
    def rule(self, x: torch.Tensor, t: int or torch.Tensor) -> torch.Tensor:
        """
        The fundamental rule function R(X, t).
        This must be implemented by the subclass.
        Args:
            x: Input tensor (seed or intermediate state)
            t: Step parameter (could be a integer step or a continuous depth value)
        Returns:
            Transformed tensor
        """
        pass

    def forward(self, x: torch.Tensor, T: Optional[int] = None) -> torch.Tensor:
        """
        The forward pass implements the full exaltation: Y = lim_{t->T} R(X, t)
        Args:
            x: The seed input X
            T: The terminal step. If None, uses a default or learns it dynamically.
        Returns:
            The final output Y
        """
        # Default implementation: iterate T times.
        # Can be overridden for more efficient schemes (e.g., using deep layers)
        h = x
        if T is None:
            T = self.default_T

        for t in range(T):
            h = self.rule(h, t)
            # Store intermediate state for introspection
            self._intermediate_states[t] = h.detach()
        return h

    def get_intermediate_state(self, t: int) -> torch.Tensor:
        """Retrieve the state of the exaltation at step t. Crucial for debugging."""
        return self._intermediate_states.get(t)

    def register_analysis_hook(self, t: int, hook_fn: Callable):
        """Register a hook to be called after step t is computed."""
        self._hooks[t] = hook_fn

# Example concrete implementation for a standard neural network
class NeuralExaltation(ExaltationOperator):
    """
    An Exaltation module built from a sequential neural network.
    Each layer in the sequential module is a step t in the exaltation process.
    """

    def __init__(self, sequential_layers: nn.Sequential, name: str = None):
        super().__init__(name=name)
        self.layers = sequential_layers
        self.default_T = len(sequential_layers)

    def rule(self, x: torch.Tensor, t: int) -> torch.Tensor:
        # For a sequential network, the rule at step t is simply applying layer t
        return self.layers[t](x)

# Module for Dynamic Early Exiting
class DynamicExaltation(NeuralExaltation):
    """
    An Exaltation that can dynamically decide its terminal step T'
    based on the confidence of its intermediate states.
    """

    def __init__(self, sequential_layers: nn.Sequential, confidence_threshold: float = 0.95):
        super().__init__(sequential_layers)
        self.confidence_threshold = confidence_threshold
        # Attach small exit classifiers to intermediate layers
        self.exit_classifiers = nn.ModuleList([
            nn.Linear(layer.output_features, num_classes) for layer in sequential_layers if hasattr(layer, 'output_features')
        ])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        for t, layer in enumerate(self.layers):
            h = layer(h) # Apply rule R(h, t)

            # Check if we can exit early
            if t < self.default_T - 1: # Don't exit at the final layer
                confidence = self._calculate_confidence(h, t)
                if confidence > self.confidence_threshold:
                    # print(f"Exiting early at layer {t} with confidence {confidence:.3f}")
                    break # Terminate exaltation early
            self._intermediate_states[t] = h.detach()
        return h

    def _calculate_confidence(self, x: torch.Tensor, t: int) -> float:
        logits = self.exit_classifiers[t](x)
        probabilities = torch.softmax(logits, dim=-1)
        max_prob = torch.max(probabilities, dim=-1)[0]
        return max_prob.mean().item()